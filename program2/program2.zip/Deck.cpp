#include "Deck.h"
//#include iostream;
#include <algorithm>
using namespace std;

Deck::Deck() {
	for (int i = 1; i < 5; i++)
	{
		for (int j = 2; j < 15 ; j++)
		{
			Card add_card(i, j);
			
			card_deck.push_back(add_card);
		}
	}
}

void Deck::shuffle() {

	random_shuffle(card_deck.begin(), card_deck.end());
}

Card  Deck::draw() {
	Card returnCard = card_deck[0];
	card_deck.erase(card_deck.begin());
	return returnCard;
}

bool Deck::empty() {
	bool ret_val = card_deck.empty();
	return ret_val;
}

void Deck::display() {
	for(int i = 0; i < card_deck.size(); i++) {
		card_deck[i].display();
	}
}