#ifndef _Test_H
#define _Test_H
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <math.h>

class Test {

public:
	std::string w;
	Test();
	int hit1;
	int total1;
	void directMapped(std::string s, int size);
	void setAssociative(std::string s, int size);
	void fullyAssociative(std::string s, int size);
	void setAssociative3(std::string s, int size);
	void setAssociative2(std::string s, int size);
	void preFetch(std::string s, int size);
};

#endif