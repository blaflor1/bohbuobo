vector< deque<int> > LRU; 
	int hit = 0;
	int total = 0;




	int cacheSize = 512;
	int sets = cacheSize/size;
	int table[sets][size];
	bool valid[sets][size];
	for(int i = 0; i<sets; i++)
		for(int j = 0; j<size; j++){
			table[i][j] = 0;
			valid[i][j] = 0;
		}

	unsigned long long addr;
	string behavior, line;
	//int sets = 32 / size; // numSets
	bool allValid[sets];
	int tableSize = (16 * 1024) / (32 * size);
	



	for(int h = 0; h < sets; h++) {
		LRU.push_back(deque<int>());
	}


	ifstream infile(s.c_str());
    while(getline(infile,line)) {
   		stringstream s(line);
   		s >> behavior >> std::hex >> addr;
   		unsigned long long tag;
   		int blockNum = addr / (32);
   		addr = addr >> 5;
   		int index = addr & sets-1;
   		addr = addr >> (unsigned long long) log2(sets);
   		tag = addr;
   		
   		bool located = false;




   		for(int y = 0; y < size; y++) {
   			if(table[index][y] == tag) {
   				hit++;
	   			located = true;
	   			LRU[index].erase(LRU[index].begin() + y);
	   			LRU[index].push_back(y);

	   			break;
   		 	}
   		}
   		if(!located){



			for(int x = 0; x < size; x++) {
				if(valid[index][x] == 0) {
					valid[index][x] = 1;
					table[index][x] = tag;
					LRU[index].push_back(x);
				}

				else if(x == size - 1) {
					int use_index = LRU[index].front();
					table[index][use_index] = tag;
					LRU[index].push_back(use_index);
					LRU[index].pop_front();

				}
			}
		

   		}
   		
   		
   		total++;

   	}
   	cout << " " << hit << ", " << total << "; " << endl;



void Test::preFetch(string s, int size){
int cacheSize = 512;
int sets_num = cacheSize/size; 
int addr;
ifstream infile(s.c_str());
LRUclass LRU;

//int cacheSize = 512;
for (int i = 0; i < size; i++) {
    LRU.array.push_back(0);
}
string behavior, line ;

int tableSize = (16 * 1024) / (32 * size);


vector<LRUclass> LRUvec;
for (int i = 0; i < tableSize; i++) {
    LRUvec.push_back(LRU);
}

int total = 0;
int hit = 0;

while(getline(infile,line)) {
    stringstream s(line);
   	s >> behavior >> std::hex >> addr;
    bool location = false;
    int tag = addr / 32;
    int setNum = tag % tableSize;
   
   	addr = addr >> 5;
   	int index = addr & sets_num - 1;
   	addr = addr >> (unsigned long long) log2(sets_num);
   	//tag = addr;
    for(int i = 0 ; i < size ; i++){
        if(LRUvec[index].array[i] == tag){
            hit++;
            location = true;
            LRUvec[index].array.erase(LRUvec[index].array.begin() + i);
            LRUvec[index].array.push_front(tag);
            
            break;
        }
    }
    if(!foundInSet)
        {
            table[setNum].array.insert(table[setNum].array.begin(), tag);
            table[setNum].array.pop_back();
            addr = addr + 32 ;
            foundInSet = false ;
            tag = addr / (32) ;
            setNum = tag % tableSize  ;
            for(int i = 0 ; i < assoc ; i++){
                if(table[setNum].array[i] == tag){
                    table[setNum].array.erase(table[setNum].array.begin() + (i));
                    table[setNum].array.insert(table[setNum].array.begin(), tag);
                
                    foundInSet = true;
                    break;
                }
            }
            if(!foundInSet)
            {
                table[setNum].array.insert(table[setNum].array.begin(), tag);
                table[setNum].array.pop_back();
            }
        }
        total ++ ;
    }
    cout << " " << hit << ", " << total << "; " ;
}