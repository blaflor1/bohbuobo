#include "Map.h"
#include <vector>
#include <list>
#include <string>
#include <fstream>
#include <iostream>
#include <sstream>
#include <deque>
using namespace std;

Map::Map(string filename) {
	ifstream myfile;
	myfile.open(filename.c_str());
	stringstream ss;
	string test;
	string test2;
	string test3;
	if(!myfile.is_open()) {
		return;
	}
	while(getline(myfile, test, '\n')) {
		stringstream stream(test);
		string name;
		stream >> name;
		int x;
		stream >> x;
		int y;
		stream >> y;
		//cout << "City name: " << name << " At x: " << x << " y: " << y << endl;
		City* newCity = new City(name, x, y);
		mapOfCities.push_back(newCity);
	}
	for(int i = 0; i < mapOfCities.size(); i++) {
		//vector<int> distanceList;
		vector<City *> newList;
		for(int j = 0; j < mapOfCities.size(); j++ ) {
			if(hasAdjacency(mapOfCities[i], mapOfCities[j]) && i != j) {
				newList.push_back(mapOfCities[j]);
			}
		}
		mapOfCities[i]->adjList = newList;
		mapOfCities[i]->correctAdjXN();
		mapOfCities[i]->correctAdjXS();
		mapOfCities[i]->correctAdjYE();
		mapOfCities[i]->correctAdjYW();
		mapOfCities[i]->calculateDistances();
		//mapOfCities[i]->displayPairs();
	}
	myfile.close();
}

City * Map::findByName(string name) {
	for(int i = 0; i != mapOfCities.size(); i++) {
		if(mapOfCities[i]->getName() == name) return mapOfCities[i];
	}
}

bool Map::inList(vector<Node*> vec, City* city1) {
	bool ret_val = false;
	for(int i = 0; i < vec.size(); i++) {
		if(vec[i]->currentCity->getName() == city1->getName()) {
			return true;
		}
	}
	return false;
}

vector<City*> Map::shortestPath(City * start, City * dest) {
	vector<City*> shortPath;
	deque<Node*> notVisited;
	vector<Node*> visited;
	
	if(start->getName() == dest->getName()) {
		shortPath.push_back(start);
		return shortPath;
	}
	if(dest->pairList.size() == 0) {
		return vector<City*>();
	}
	
	for(int i = 0; i < mapOfCities.size(); i++) {
			
		if(mapOfCities[i]->getName() == start->getName()) {

			Node * add_node = new Node(mapOfCities[i], 0);
			
			notVisited.push_back(add_node);
		}	else {
			Node * add_node1 = new Node(mapOfCities[i], 9999);
			notVisited.push_back(add_node1);
		}
			
	}
	if(start->isAdj(dest)) {
		shortPath.push_back(start);
		shortPath.push_back(dest);
		return shortPath;
	}
	else {
		unsigned int shortest = notVisited[0]->distance;
		int short_ind = 0;
		Node * shortestNode;
		City * explore = NULL;
		for(int i = 0; i < notVisited.size(); i++) {
			if(notVisited[i]->distance < shortest) {
				shortest = notVisited[i]->distance;
				shortestNode = notVisited[i];
				short_ind = i;
				explore = notVisited[i]->currentCity;
			}
		}
		Node * temp;
		while(notVisited.size() > 1) {
			int max = 0;
			temp = new Node(notVisited.front()->currentCity, notVisited.front()->distance, notVisited.front()->previous);
			//temp->currentCity->displayPairs();
			for(int i = 0; i < notVisited.size(); i++) {
				if(notVisited[i]->distance < temp->distance) {
					
					temp = notVisited[i];
					max = i;
				}
			}
			
			if(temp->currentCity->getName() == dest->getName()) {
				
				return findRoute(start, temp, visited);

			}
			if(temp->currentCity->pairList.size() > 0){
				for(int i = 0; i < temp->currentCity->pairList.size(); i++) {
					if(!inList(visited, temp->currentCity->pairList[i].first)) {
						Node * temp2 = NULL;
						for(int j = 0; j < notVisited.size(); j++) {

							if(temp->currentCity->pairList[i].first->getName() == notVisited[j]->currentCity->getName()) {
							
								temp2 = notVisited[j];
								
								if((temp->currentCity->pairList[i].second)  + (temp->distance) < temp2->distance) {
									temp2->distance = (temp->currentCity->pairList[i].second) + temp->distance;
									temp2->previous = temp->currentCity;
								}
								
							}
						}

						
						if((temp->currentCity->pairList[i].second)  + (temp->distance) < temp2->distance) {
							temp2->distance = (temp->currentCity->pairList[i].second) + temp->distance;
						}
					}
				}

			}
			visited.push_back(temp);
			notVisited.erase(notVisited.begin() + max);
			


		}

	}

}



bool Map::hasAdjacency(City* start, City * dest) {
	bool ret_val = false;
	if(start->getYCoor() == dest->getYCoor() && start->getXCoor() != dest->getXCoor()) {
		// East Block
		if(start->getXCoor() < dest->getXCoor() && start->getEast() == NULL) {
			start->setEast(dest);
			ret_val = true;
		}
		else if(start->getXCoor() < dest->getXCoor() && start->getEast() != NULL) {

			if(start->getEast()->getXCoor() > dest->getXCoor()) {
				
				for(int i = 0; i < start->getAdjacency().size(); i++){
					if(start->getAdjacency()[i]->getName() == start->getEast()->getName()) {
						start->getAdjacency().erase(start->getAdjacency().begin() + i);
						break;
					}
				}
				start->setEast(dest);
				ret_val = true;
			}
			else if(dest->getXCoor() > start->getEast()->getXCoor()) {
				return false;
			} 
			
		} // End East Block
		//Begin West Block
		else if(start->getXCoor() > dest->getXCoor()){
			if(start->getWest() == NULL) {
				start->setWest(dest);
				ret_val = true;
			}
			else if(start->getWest() != NULL) {
				if(start->getWest()->getXCoor() < dest->getXCoor()) {
					for(int i = 0; i < start->getAdjacency().size(); i++){
						if(start->getAdjacency()[i]->getName() == start->getWest()->getName()){
							start->getAdjacency().erase(start->getAdjacency().begin() + i);
							break;
						}
					}
					start->setWest(dest);
					return true;
				}
				else if(start->getWest()->getXCoor() > dest->getXCoor()) {
					return false;
				}
			}
		}
	}
	// North - South block
	else if(start->getXCoor() == dest->getXCoor()) {
		if(start->getYCoor() > dest->getYCoor()) {
			if(start->getSouth() == NULL) {
				start->setSouth(dest);
				return true;
			}
			else if(start->getSouth() != NULL) {
				if(start->getSouth()->getYCoor() < dest->getYCoor()) {
					for(int i = 0; i < start->getAdjacency().size(); i++){
						if(start->getAdjacency()[i]->getName() == start->getSouth()->getName()){
							start->getAdjacency().erase(start->getAdjacency().begin() + i);
							break;
						}
					}
					start->setSouth(dest);
					return true;
				}
				else if(start->getSouth()->getYCoor() > dest->getYCoor()) {
					return false;
				}
			}
		}
		else if(start->getYCoor() < dest->getYCoor()) {

			if(start->getNorth() == NULL) {
				start->setNorth(dest);
				return true;
			}
			else if(start->getNorth() != NULL) {
				if(start->getNorth()->getYCoor() > dest->getYCoor()) {
					for(int i = 0; i < start->getAdjacency().size(); i++){
						if(start->getAdjacency()[i]->getName() == start->getNorth()->getName()){
							start->getAdjacency().erase(start->getAdjacency().begin() + i);
						}
					}
					start->setNorth(dest);
					return true;
				}
				else if(start->getNorth()->getYCoor() < dest->getYCoor()) {
					return false;
				}
			}
		}

		
}
	return ret_val;
}

unsigned int Map::pathDistance(City * start, City * dest) {
	if(start->getXCoor() == dest->getXCoor() && start->getYCoor() == dest->getYCoor()) return 0;
	
	else {
		vector<City*> shortPath = shortestPath(start, dest);
		if(shortPath.empty()) return -1;
		
		int distance = 0;
		for (int i = 0; i < shortPath.size() - 1; ++i)
		{
			if(shortPath[i]->getXCoor() == shortPath[i+1]->getXCoor()) {
				int diff = (shortPath[i]->getYCoor()) - (shortPath[i+1]->getYCoor());
				if(diff < 0) diff = diff * -1;
				distance += diff;
			}
			else if(shortPath[i]->getYCoor() == shortPath[i+1]->getYCoor()) {
				int diff = (shortPath[i]->getXCoor()) - (shortPath[i+1]->getXCoor());
				if(diff < 0) diff = diff * -1;
				distance += diff;
			}
		}
		return distance;
	}

}

vector<City*> Map::findRoute(City* start, Node* dest, vector<Node*> truth) {
	
	truth.push_back(dest);
	vector<City*> shortestPath;
	shortestPath.push_back(dest->currentCity);
	Node * temp = dest;
	
	while(!truth.empty()) {
		Node * temp2;
	
		for(int i = 0; i < truth.size(); i++) {
			
			temp2 = truth[i];
			
			if(temp->previous != NULL && temp->previous == temp2->currentCity) {
				
				

				shortestPath.push_back(temp2->currentCity);
				temp = temp2;
				if(temp->currentCity == start) {
					vector<City*> shortPath;
					for(int i = shortestPath.size() - 1; i > -1; i--) {
						
						shortPath.push_back(shortestPath[i]);
					}
					

					return shortPath;
				}
			}
		}
	}
}


