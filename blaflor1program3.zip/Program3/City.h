#include <vector>
#include <iostream>
#include <string>
#include <list>
#ifndef _City_H
#define _City_H

class City {
private:
	std::string cityName;
	int xCoor;
	int yCoor;
	
	City * north;
	City * south;
	City * east;
	City * west;

public:
	~City();
	std::vector<std::pair<City*, unsigned int>> pairList;
	//std::vector<pair<City*, int>> shortPath;
	std::vector<City*> adjList;
	bool explored;
	int minimumDistance;
	bool addCity(City * c);
	void displayPairs();
	void calculateDistances();
	std::string getName() {
		return cityName;
	}

	void setNorth(City * c) {
		north = c;
	}

	void setSouth(City * c) {
		south = c;
	}

	void setEast(City *c) {
		east = c;
	}

	void setWest(City * c ) {
		west = c;
	}
	City * getSouth() {
		return south;
	}
	City * getNorth() {
		return north;
	}
	City * getEast() {
		return east;
	}
	City * getWest() {
		return west;
	}
	City(std::string cityName, int xCoor, int yCoor);
	int getXCoor() {
		return xCoor;
	}
	int getYCoor() {
		return yCoor;
	}
	std::list<City*>getAdjacent() {
		std::list<City*> returnList;
		for(int i = 0; i < pairList.size(); i++) {
			returnList.push_back(pairList[i].first);
		}
		return returnList;
	}
	std::vector<City*>getAdjacency() {
		return adjList;
	}
	bool operator<(City &c) {
		bool ret_val = false;
		if(cityName < c.getName()) ret_val = true;
		return ret_val;
	}
	void display();
	bool correctAdj();
	void removeAdj(std::string name);
	void correctAdjXN();
	void correctAdjXS();
	void correctAdjYE();
	void correctAdjYW();
	bool isAdj(City* c);
	


};

#endif