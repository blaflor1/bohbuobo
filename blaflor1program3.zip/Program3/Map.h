#include <vector>
#include "City.h"
#include <list>
#include <fstream> 
#ifndef _Map_H
#define _Map_H

class Map {
private:

public:
	class Node {
	public:
		City * previous;
		City * currentCity;
		unsigned int distance;
		Node() {
			previous = NULL;
			currentCity = NULL;
			distance = 0;
		}
		Node(City* c, unsigned int d) {
			previous = NULL;
			currentCity = c;
			distance = d;
		}
		Node(City* c, unsigned d, City * p) {
			previous = p;
			currentCity = c;
			distance = d;
		}
	};
	std::vector<City*> mapOfCities;
	Map(std::string filename);
	City* findByName(std::string cityName);
	std::vector<City*> shortestPath(City * start, City * dest);
	unsigned int pathDistance (City * start, City * dest);
	bool hasAdjacency(City *start, City * dest);
	std::vector<City*> findRoute(City* start, Node* dest, std::vector<Node*> v);
	bool inList(std::vector<Node*> v, City * c);
};
#endif