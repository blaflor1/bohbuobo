#include <string>
#include <iostream>
#include <vector>
#include <fstream>
#include <queue>
#include <deque>
#include <sstream>
#include <algorithm>
#include "Node.h"
#include "Project2.h"

using namespace std;

struct mycomparison {
	bool operator() (const Node& node1, const Node& node2) {
		return node2.bound > node1.bound;
	}
};
//Make tree (probably array form?) of graph... then use priority queue method to find
/*  priority_queue PQ; node u, v;
  //initialize
  initialize(PQ); 
  v=root of T; 
  best=value(v);
  insert(PQ,v);
  }*/


int Project2::bound(Node start,  deque<Item> item_graph)
{
    
    if (start.weight >= capacity) {
        return 0;
    }
    
    int bound = start.profit;
 
    // start including items from index 1 more to current
    // item index
    int j = start.depth + 1;
    int totweight = start.weight;
 
    // checking index condition and knapsack capacity
    // condition
    while ((j < this->size) && (totweight + item_graph[j].weight <= this->capacity))
    {
        totweight    += item_graph[j].weight;
        bound += item_graph[j].amount;
        j++;
    }
 
    // If k is not n, include last item partially for
    // upper bound on profit
    if (j < this->size)
        bound += (this->capacity - totweight) * (item_graph[j].amount /item_graph[j].weight);
 
    return bound;
}

deque<Item> Project2::createPriorityQueue(vector<Item> unsorted_vec) {
	deque<Item> priority;
	deque<float> ratios;
	//sort(unsorted_vec.rbegin(), unsorted_vec.rend());
	int max = 0;
	for (int i = 0; i < unsorted_vec.size(); ++i)
	{	
		if(i = 0) {
			priority.push_back(unsorted_vec[i]);
			ratios.push_back((float)unsorted_vec[i].weight/unsorted_vec[i].amount);

		}
		else {
			if((unsorted_vec[i].weight/unsorted_vec[i].amount) > (unsorted_vec[max].weight/unsorted_vec[max].amount)) {
				ratios.push_front(unsorted_vec[i].weight/unsorted_vec[i].amount);
				i = max;
			}
			else {
				ratios.push_back((float)unsorted_vec[i].weight/unsorted_vec[i].amount);
			}
		}
	}
	sort(ratios.rbegin(), ratios.rend());
	for (int i = ratios.size() - 1; i >= 0; ++i)
	{
		for(int j = 0; j < unsorted_vec.size(); j++) {
			if(ratios[i] == ((float)unsorted_vec[j].weight/unsorted_vec[j].amount)) {
				priority.push_front(unsorted_vec[j]);
			}
		}
	}
	
	return priority;
}

int Project2::knapsack01(deque<Item> items_list, int depth)  {
    //for (int i = 0; i < items.length; ++i)
    //{
    	
    //}
 	//sort(items_list, items_list + depth, cmp)
 	// = createPriorityQueue(items_list);
    // make a queue for traversing the node

    priority_queue<Node, vector<Node>, mycomparison> PQ;
    deque<Item> solutions;
    Node x; 
    Node y;
    x.depth = -1;
    x.weight = 0;
    x.profit = 0;
    x.bound = bound(x, items_list);
    PQ.push(x);
    int maxProfit = 0;
    while (!PQ.empty())  {
    	;
        
        x = PQ.top();
        PQ.pop();
 
        if(x.bound > maxProfit) {
	        if (x.depth < 0){
	            y.depth = 0;
	        }      
	        else if (x.depth == depth-1) {
	        	this->leaf_nodes++;
	            continue;
	        }
	        y.depth = x.depth + 1;
	        y.weight = x.weight + items_list[y.depth].weight;
	        y.profit = x.profit + items_list[y.depth].amount;
	        this->visited++;
	        y.included_items = x.included_items;
	        y.addItem(items_list[y.depth]);
	        if (y.weight <= this->capacity && y.profit > maxProfit) {
	            maxProfit = y.profit;
	            this->solution = y.included_items;
	        }

	        y.bound = bound(y, items_list);
	        if (y.bound > maxProfit){
	            PQ.push(y);
	        } 
	        else {
	        	this->leaf_nodes++;
	        }
	        y.weight = x.weight;
	        y.profit = x.profit;
	        y.bound = bound(y, items_list);
	        this->visited++;
	        y.included_items = x.included_items;
	        if (y.bound > maxProfit){
	            PQ.push(y);
	        } else {
	        	this->leaf_nodes++;
	        }
        }
        else {
        	this->leaf_nodes++;
        }
    }
 	this->visited = this->visited + 1;
    return maxProfit;
}



